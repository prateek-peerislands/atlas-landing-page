#!/usr/bin/env node

// Debug script to understand Atlas API response format
const MCP_SERVER_URL = 'http://localhost:3001';

async function debugAtlasResponse() {
  console.log('🔍 Debugging Atlas API Response Format...\n');

  try {
    // Test cluster creation to see the actual response
    console.log('1️⃣ Testing cluster creation to see Atlas response...');
    const testClusterName = 'debug-test-' + Date.now();
    
    const createResponse = await fetch(`${MCP_SERVER_URL}/create-cluster`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        clusterName: testClusterName,
        tier: 'M10'
      })
    });
    
    if (createResponse.ok) {
      const createData = await createResponse.json();
      console.log('✅ Cluster creation response:');
      console.log(JSON.stringify(createData, null, 2));
      
      // Check what fields are available
      console.log('\n📋 Response field analysis:');
      console.log(`- Has 'id' field: ${!!createData.id}`);
      console.log(`- Has 'name' field: ${!!createData.name}`);
      console.log(`- Has 'stateName' field: ${!!createData.stateName}`);
      console.log(`- ID value: ${createData.id}`);
      console.log(`- Name value: ${createData.name}`);
      console.log(`- State value: ${createData.stateName}`);
      
      if (createData.requestId) {
        console.log('\n2️⃣ Waiting 5 seconds then checking status...');
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        const statusResponse = await fetch(`${MCP_SERVER_URL}/api/cluster-status?id=${createData.requestId}`);
        if (statusResponse.ok) {
          const statusData = await statusResponse.json();
          console.log('✅ Status response:');
          console.log(JSON.stringify(statusData, null, 2));
        } else {
          console.log('❌ Status check failed:', statusResponse.status);
        }
      }
    } else {
      const errorData = await createResponse.json();
      console.log('⚠️ Cluster creation failed:', errorData.message);
    }

    console.log('\n🎯 Debug completed!');
    console.log('\n💡 This will help understand the exact Atlas API response format');

  } catch (error) {
    console.error('❌ Debug failed:', error.message);
    console.log('\n💡 Make sure the MCP server is running on port 3001');
    console.log('   Run: ./start-mcp-server.sh');
  }
}

debugAtlasResponse();
