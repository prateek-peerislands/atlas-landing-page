#!/usr/bin/env node

// Load environment variables from .env file
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.MCP_SERVER_PORT || 3001;

// Enable CORS for frontend communication
app.use(cors());
app.use(express.json());

console.log('Starting MCP Server on port', PORT);

// Store MCP process reference
let mcpProcess = null;

// Store cluster requests for status tracking with persistence
const clusterRequests = new Map();

// Persistence file path
const PERSISTENCE_FILE = path.join(__dirname, 'cluster-requests.json');

// Load persisted cluster requests on startup with cleanup
function loadPersistedRequests() {
  try {
    if (fs.existsSync(PERSISTENCE_FILE)) {
      const data = fs.readFileSync(PERSISTENCE_FILE, 'utf8');
      const requests = JSON.parse(data);
      console.log(`Loaded ${requests.length} persisted cluster requests`);
      
      // Clean up old/failed requests and keep only active ones
      const now = Date.now();
      const maxAge = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
      
      requests.forEach(request => {
        const requestAge = now - request.startTime;
        
        // Keep only:
        // 1. Active requests (CREATING, INITIALIZING) that are less than 24 hours old
        // 2. Successfully completed requests (IDLE) that are less than 24 hours old
        // 3. Failed requests that are less than 1 hour old (for debugging)
        
        if (request.state === 'IDLE' && requestAge < maxAge) {
          // Keep recent successful clusters
          clusterRequests.set(request.id, request);
        } else if (request.state === 'CREATING' || request.state === 'INITIALIZING') {
          if (requestAge < maxAge) {
            // Keep recent active clusters
            clusterRequests.set(request.id, request);
          } else {
            // Mark old stuck clusters as failed
            request.state = 'FAILED';
            request.statusMessage = 'Cluster creation timed out (older than 24 hours)';
            clusterRequests.set(request.id, request);
          }
        } else if (request.state === 'FAILED' && requestAge < (60 * 60 * 1000)) {
          // Keep recent failed clusters for debugging (1 hour)
          clusterRequests.set(request.id, request);
        }
        // Discard old failed/stuck requests
      });
      
      // Save cleaned up requests
      saveRequestsToFile();
      console.log(`After cleanup: ${clusterRequests.size} active cluster requests remain`);
    }
  } catch (error) {
    console.error('Failed to load persisted requests:', error);
  }
}

// Save cluster requests to file
function saveRequestsToFile() {
  try {
    const requests = Array.from(clusterRequests.values());
    fs.writeFileSync(PERSISTENCE_FILE, JSON.stringify(requests, null, 2));
  } catch (error) {
    console.error('Failed to save requests to file:', error);
  }
}

// Load persisted requests on startup
loadPersistedRequests();

// Memory check function to ensure cluster requests don't get lost
function checkMemoryIntegrity() {
  console.log(`Memory check: ${clusterRequests.size} cluster requests in memory`);
  for (const [id, request] of clusterRequests.entries()) {
    console.log(`  - ${id}: ${request.clusterName} (${request.state}) - ${request.progress}%`);
  }
}

// Clean up old and failed requests
function cleanupOldRequests() {
  const now = Date.now();
  const maxAge = 24 * 60 * 60 * 1000; // 24 hours
  const failedMaxAge = 60 * 60 * 1000; // 1 hour for failed requests
  
  let cleanedCount = 0;
  
  for (const [id, request] of clusterRequests.entries()) {
    const requestAge = now - request.startTime;
    let shouldRemove = false;
    
    if (request.state === 'IDLE' && requestAge > maxAge) {
      shouldRemove = true; // Remove old completed clusters
    } else if (request.state === 'FAILED' && requestAge > failedMaxAge) {
      shouldRemove = true; // Remove old failed clusters
    } else if (requestAge > maxAge) {
      // Mark very old requests as failed and remove
      request.state = 'FAILED';
      request.statusMessage = 'Cluster creation timed out (older than 24 hours)';
      shouldRemove = true;
    }
    
    if (shouldRemove) {
      clusterRequests.delete(id);
      cleanedCount++;
    }
  }
  
  if (cleanedCount > 0) {
    console.log(`Cleaned up ${cleanedCount} old cluster requests`);
    saveRequestsToFile();
  }
}

// Run memory check every 60 seconds
setInterval(checkMemoryIntegrity, 60000);

// Clean up old requests every 5 minutes
setInterval(cleanupOldRequests, 5 * 60 * 1000);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    mcpConnected: mcpProcess !== null,
    port: PORT 
  });
});

// Clear all cluster requests endpoint (for development/testing)
app.post('/api/clear-all-requests', (req, res) => {
  try {
    const previousCount = clusterRequests.size;
    clusterRequests.clear();
    
    // Remove persistence file
    if (fs.existsSync(PERSISTENCE_FILE)) {
      fs.unlinkSync(PERSISTENCE_FILE);
    }
    
    console.log(`Cleared all ${previousCount} cluster requests`);
    res.json({ 
      success: true, 
      message: `Cleared ${previousCount} cluster requests`,
      clearedCount: previousCount
    });
  } catch (error) {
    console.error('Error clearing requests:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Start MCP server endpoint
app.post('/api/start-mcp', async (req, res) => {
  try {
    console.log("Starting MongoDB-MCP server...");
    
    // Start MongoDB-MCP server with credentials
    mcpProcess = spawn("npx", [
      "--yes",
      "mongodb-mcp-server"
    ], {
      env: {
        ...process.env,
        ATLAS_CLIENT_ID: process.env.VITE_MDB_MCP_API_CLIENT_ID,
        ATLAS_CLIENT_SECRET: process.env.VITE_MDB_MCP_API_CLIENT_SECRET,
        MONGODB_PROJECT_ID: process.env.VITE_MONGODB_PUBLIC_KEY
      }
    });

    // Handle MCP server output
    if (mcpProcess.stdout) {
      mcpProcess.stdout.on('data', (data) => {
        console.log('MCP Server:', data.toString().trim());
      });
    }

    if (mcpProcess.stderr) {
      mcpProcess.stderr.on('data', (data) => {
        console.error('MCP Server Error:', data.toString().trim());
      });
    }

    mcpProcess.on('close', (code) => {
      console.log(`MCP Server process exited with code ${code}`);
      mcpProcess = null;
    });

    res.json({ success: true, message: "MCP Server started successfully" });
  } catch (error) {
    console.error('Failed to start MCP server:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create cluster endpoint
app.post('/create-cluster', async (req, res) => {
  try {
    const { clusterName, tier } = req.body;
    
    if (!clusterName || !tier) {
      return res.status(400).json({ 
        success: false, 
        message: "Cluster name and tier are required" 
      });
    }

    // Validate cluster name format
    if (!/^[a-zA-Z0-9-]+$/.test(clusterName) || clusterName.length < 1 || clusterName.length > 64) {
      return res.status(400).json({
        success: false,
        message: "Cluster name must be 1-64 characters, letters, numbers, and hyphens only"
      });
    }

    // Validate tier
    const validTiers = ['M10', 'M20', 'M30'];
    if (!validTiers.includes(tier)) {
      return res.status(400).json({
        success: false,
        message: "Invalid tier. Must be one of: M10, M20, M30"
      });
    }

    // Check if cluster name already exists
    const existingCluster = Array.from(clusterRequests.values()).find(
      req => req.clusterName === clusterName && req.state !== 'FAILED'
    );
    
    if (existingCluster) {
      return res.status(400).json({
        success: false,
        message: `Cluster with name "${clusterName}" already exists or is being created`
      });
    }

    // Generate unique request ID
    const requestId = `req-${Date.now()}`;
    
    // Create cluster request object
    const clusterRequest = {
      id: requestId,
      clusterName: clusterName,
      tier: tier,
      state: 'INITIALIZING',
      progress: 10,
      startTime: Date.now(),
      statusMessage: 'Initializing cluster creation...',
      isDataPopulated: false,
      dataCollections: []
    };
    
    clusterRequests.set(requestId, clusterRequest);
    saveRequestsToFile();
    
    // Start progress simulation - 8 minutes total, update every 40 seconds
    const totalDuration = 8 * 60 * 1000; // 8 minutes in milliseconds
    const updateInterval = 40 * 1000; // 40 seconds in milliseconds
    
    const progressInterval = setInterval(() => {
      const currentRequest = clusterRequests.get(requestId);
      if (!currentRequest) {
        clearInterval(progressInterval);
        return;
      }
      
      // Calculate elapsed time and progress
      const elapsed = Date.now() - currentRequest.startTime;
      const elapsedSeconds = Math.floor(elapsed / 1000);
      
      // Update progress gradually from 10% to 95% (not 90%)
      if (currentRequest.progress < 95) {
        currentRequest.progress = Math.min(95, Math.round(10 + (elapsed / totalDuration) * 85));
        
        // Update status message based on progress
        if (currentRequest.progress < 25) {
          currentRequest.statusMessage = `Initializing cluster configuration... (${elapsedSeconds}s)`;
        } else if (currentRequest.progress < 40) {
          currentRequest.statusMessage = `Provisioning cloud infrastructure... (${elapsedSeconds}s)`;
        } else if (currentRequest.progress < 55) {
          currentRequest.statusMessage = `Setting up MongoDB instances... (${elapsedSeconds}s)`;
        } else if (currentRequest.progress < 70) {
          currentRequest.statusMessage = `Configuring replication and security... (${elapsedSeconds}s)`;
        } else if (currentRequest.progress < 85) {
          currentRequest.statusMessage = `Finalizing cluster setup... (${elapsedSeconds}s)`;
        } else {
          currentRequest.statusMessage = `Almost complete... (${elapsedSeconds}s)`;
        }
        
        saveRequestsToFile();
      }
    }, updateInterval);
    
    // Create real cluster in MongoDB Atlas
    const clusterConfig = {
      name: clusterName,
      clusterType: "REPLICASET",
      replicationSpecs: [{
        numShards: 1,
        regionsConfig: {
          "US_EAST_2": {
            electableNodes: 3,
            priority: 7,
            readOnlyNodes: 0
          }
        }
      }],
      providerSettings: {
        providerName: "AZURE",
        instanceSizeName: tier,
        regionName: "US_EAST_2"
      },
      mongoDBMajorVersion: "7.0"
    };
    
    // Use Atlas API to create the cluster
    const { exec } = require('child_process');
    const postData = JSON.stringify(clusterConfig);
    
    // Use the actual credentials from the .env file
    const publicKey = process.env.MONGODB_PUBLIC_KEY || "vcammlal";
    const privateKey = process.env.MONGODB_PRIVATE_KEY || "d94cc8c6-3c3c-496f-b53f-94726270eb90";
    const groupId = process.env.MONGODB_GROUP_ID || "688ba44a7f3cd609ef39f683";
    
    const curlCommand = `curl -s --digest -u "${publicKey}:${privateKey}" \
      -X POST "https://cloud.mongodb.com/api/atlas/v1.0/groups/${groupId}/clusters" \
      -H "Content-Type: application/json" \
      -d '${postData.replace(/'/g, "'\\''")}' \
      --max-time 30`;
    
    exec(curlCommand, (error, stdout, stderr) => {
      if (error) {
        console.error('Atlas API Error:', error);
        clearInterval(progressInterval);
        const failedRequest = clusterRequests.get(requestId);
        if (failedRequest) {
          failedRequest.state = 'FAILED';
          failedRequest.progress = 0;
          failedRequest.statusMessage = `Cluster creation failed: ${error.message}`;
          clusterRequests.set(requestId, failedRequest);
          saveRequestsToFile();
        }
        return;
      }
      
      if (stderr && stderr.trim()) {
        console.error('Atlas API stderr:', stderr);
      }
      
      try {
        const result = JSON.parse(stdout);
        
        // Check if this is an error response from Atlas
        if (result.error || result.errorCode || result.detail) {
          console.error(`Atlas API Error Response:`, result);
          console.error(`Error details: ${result.detail || result.reason || result.error || "Unknown error"}`);
          
          clearInterval(progressInterval);
          const failedRequest = clusterRequests.get(requestId);
          if (failedRequest) {
            failedRequest.state = 'FAILED';
            failedRequest.progress = 0;
            failedRequest.statusMessage = `Atlas API Error: ${result.detail || result.reason || result.error || "Unknown error"}`;
            clusterRequests.set(requestId, failedRequest);
            saveRequestsToFile();
            console.log(`Marked cluster request ${requestId} as failed due to Atlas API error`);
          }
          return;
        }
        
        // Handle different Atlas API response formats
        if (result.id) {
          console.log(`Cluster creation response received from Atlas!`);
          console.log(`Atlas Response ID: ${result.id}`);
          console.log(`Full Atlas creation response:`, JSON.stringify(result, null, 2));
          
          // Determine the actual cluster name - it might be in result.id or result.name
          let actualClusterName = clusterName;
          let atlasClusterId = result.id;
          
          // If result.id looks like a cluster name (contains letters/numbers but not just hex), use it
          if (result.id && result.id !== clusterName && /[a-zA-Z]/.test(result.id)) {
            actualClusterName = result.id;
            console.log(`Using Atlas response ID as cluster name: ${actualClusterName}`);
          }
          
          // If result.name exists and is different, use that
          if (result.name && result.name !== clusterName) {
            actualClusterName = result.name;
            console.log(`Using Atlas response name as cluster name: ${actualClusterName}`);
          }
          
          // Check for other possible cluster name fields
          if (result.clusterName && result.clusterName !== clusterName) {
            actualClusterName = result.clusterName;
            console.log(`Using Atlas response clusterName as cluster name: ${actualClusterName}`);
          }
          
          // Log what we're going to use for status checks
          console.log(`Status check will use cluster name: "${actualClusterName}"`);
          console.log(`Original user input was: "${clusterName}"`);
          
          // Check if this is actually a successful cluster creation or just a request acknowledgment
          if (result.stateName && result.stateName === 'CREATING') {
            console.log(`Cluster creation confirmed - Atlas is now creating the cluster`);
          } else if (result.stateName) {
            console.log(`Cluster creation response state: ${result.stateName}`);
          } else {
            console.log(`Cluster creation request acknowledged - monitoring for actual creation`);
          }
          
          // Update cluster request with Atlas cluster ID and actual cluster name
          const currentRequest = clusterRequests.get(requestId);
          if (currentRequest) {
            currentRequest.clusterId = atlasClusterId;
            currentRequest.actualClusterName = actualClusterName; // Store the actual name Atlas uses
            currentRequest.state = 'CREATING';
            currentRequest.progress = 20;
            currentRequest.statusMessage = 'Cluster creation in progress in Atlas...';
            clusterRequests.set(requestId, currentRequest);
            saveRequestsToFile();
            console.log(`Updated cluster request ${requestId} with Atlas cluster ID ${atlasClusterId} and name ${actualClusterName}`);
          } else {
            console.error(`Cluster request ${requestId} not found in memory!`);
            return;
          }
          
          // Start monitoring Atlas cluster status every 10 seconds
          // Add a delay to give Atlas time to start creating the cluster
          console.log(`Waiting 30 seconds before starting status monitoring...`);
          setTimeout(() => {
            console.log(`Starting Atlas cluster status monitoring for "${clusterName}"...`);
            
            const statusCheckInterval = setInterval(async () => {
              const currentRequest = clusterRequests.get(requestId);
              if (!currentRequest) {
                console.error(`Cluster request ${requestId} disappeared during status monitoring!`);
                console.error(`Available requests:`, Array.from(clusterRequests.keys()));
                
                // Try to reload from persistence file
                loadPersistedRequests();
                const reloadedRequest = clusterRequests.get(requestId);
                if (reloadedRequest) {
                  console.log(`Recovered cluster request ${requestId} from persistence file`);
                } else {
                  console.error(`Could not recover cluster request ${requestId}, stopping monitoring`);
                  clearInterval(statusCheckInterval);
                  return;
                }
              }
              
              console.log(`Checking Atlas status for cluster "${clusterName}"...`);
              
              try {
                // Use the actual cluster name that Atlas expects, not the user input
                const currentRequest = clusterRequests.get(requestId);
                const actualClusterName = currentRequest?.actualClusterName || clusterName;
                
                console.log(`Using actual cluster name for status check: "${actualClusterName}" (user input: "${clusterName}")`);
                
                // Use cluster name instead of ID for status check - this is more reliable
                const statusCurlCommand = `curl -s --digest -u "${publicKey}:${privateKey}" \
                  -X GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${groupId}/clusters/${actualClusterName}" \
                  --max-time 10`;
                
                exec(statusCurlCommand, (statusError, statusStdout, statusStderr) => {
                  if (statusError) {
                    console.error('Error checking Atlas status:', statusError);
                    return;
                  }
                  
                  if (statusStdout) {
                    try {
                      const statusResult = JSON.parse(statusStdout);
                      console.log(`Full Atlas response:`, JSON.stringify(statusResult, null, 2));
                      
                      // Check if this is an error response from Atlas
                      if (statusResult.error || statusResult.errorCode || statusResult.detail) {
                        console.error(`Atlas API Error Response:`, statusResult);
                        console.error(`Error details: ${statusResult.detail || statusResult.reason || statusResult.error || "Unknown error"}`);
                        
                        // If the error is "cluster not found", it might still be creating
                        if (statusResult.errorCode === 'CLUSTER_NOT_FOUND' || 
                            (statusResult.detail && statusResult.detail.includes('No cluster named'))) {
                          console.log(`Cluster "${actualClusterName}" not found yet - still being created`);
                          
                          // Try fallback to user input name if we're using Atlas response name
                          if (actualClusterName !== clusterName) {
                            console.log(`Trying fallback with user input name: "${clusterName}"`);
                            const fallbackCurlCommand = `curl -s --digest -u "${publicKey}:${privateKey}" \
                              -X GET "https://cloud.mongodb.com/api/atlas/v1.0/groups/${groupId}/clusters/${clusterName}" \
                              --max-time 10`;
                            
                            exec(fallbackCurlCommand, (fallbackError, fallbackStdout, fallbackStderr) => {
                              if (!fallbackError && fallbackStdout) {
                                try {
                                  const fallbackResult = JSON.parse(fallbackStdout);
                                  if (!fallbackResult.error && !fallbackResult.errorCode && !fallbackResult.detail) {
                                    console.log(`Fallback successful! Cluster found with user input name: "${clusterName}"`);
                                    // Update the actual cluster name to use user input
                                    const currentRequest = clusterRequests.get(requestId);
                                    if (currentRequest) {
                                      currentRequest.actualClusterName = clusterName;
                                      clusterRequests.set(requestId, currentRequest);
                                      saveRequestsToFile();
                                    }
                                  } else {
                                    console.log(`Fallback also failed - cluster still being created`);
                                  }
                                } catch (parseError) {
                                  console.log(`Fallback response parsing failed - cluster still being created`);
                                }
                              }
                            });
                          }
                          
                          // Don't mark as failed, just continue monitoring
                          return;
                        }
                        
                        // Mark cluster as failed due to Atlas API error
                        clearInterval(progressInterval);
                        clearInterval(statusCheckInterval);
                        
                        const failedRequest = clusterRequests.get(requestId);
                        if (failedRequest) {
                          failedRequest.state = 'FAILED';
                          failedRequest.progress = 0;
                          failedRequest.statusMessage = `Atlas API Error: ${statusResult.detail || statusResult.reason || statusResult.error || "Unknown error"}`;
                          clusterRequests.set(requestId, failedRequest);
                          saveRequestsToFile();
                          console.log(`Marked cluster request ${requestId} as failed due to Atlas API error`);
                        }
                        return;
                      }
                      
                      // Check if stateName exists in the response
                      if (!statusResult.stateName) {
                        console.error(`Atlas response missing stateName field`);
                        console.error(`Available fields:`, Object.keys(statusResult));
                        
                        // Mark cluster as failed due to unexpected response format
                        clearInterval(progressInterval);
                        clearInterval(statusCheckInterval);
                        
                        const failedRequest = clusterRequests.get(requestId);
                        if (failedRequest) {
                          failedRequest.state = 'FAILED';
                          failedRequest.progress = 0;
                          failedRequest.statusMessage = 'Unexpected response format from Atlas API';
                          clusterRequests.set(requestId, failedRequest);
                          saveRequestsToFile();
                          console.log(`Marked cluster request ${requestId} as failed due to unexpected response format`);
                        }
                        return;
                      }
                      
                      // Use stateName as per MongoDB Atlas documentation
                      const clusterState = statusResult.stateName;
                      console.log(`Atlas status for ${clusterName}: ${clusterState}`);
                      
                      if (clusterState === 'IDLE') {
                        // Cluster is ready - mark as completed
                        console.log(`Cluster "${clusterName}" is now ready in Atlas!`);
                        clearInterval(progressInterval);
                        clearInterval(statusCheckInterval);
                        
                        const completedRequest = clusterRequests.get(requestId);
                        if (completedRequest) {
                          completedRequest.state = 'IDLE';
                          completedRequest.progress = 100;
                          completedRequest.statusMessage = 'Cluster creation completed successfully! 🎉';
                          // Store the actual cluster ID from the status response
                          if (statusResult.id) {
                            completedRequest.clusterId = statusResult.id;
                          }
                          clusterRequests.set(requestId, completedRequest);
                          saveRequestsToFile();
                          console.log(`Marked cluster request ${requestId} as completed`);
                        } else {
                          console.error(`Could not find cluster request ${requestId} to mark as completed`);
                        }
                      } else if (clusterState === 'FAILED') {
                        // Cluster creation failed
                        console.log(`Cluster "${clusterName}" creation failed in Atlas`);
                        clearInterval(progressInterval);
                        clearInterval(statusCheckInterval);
                        
                        const failedRequest = clusterRequests.get(requestId);
                        if (failedRequest) {
                          failedRequest.state = 'FAILED';
                          failedRequest.progress = 0;
                          failedRequest.statusMessage = 'Cluster creation failed in Atlas';
                          clusterRequests.set(requestId, failedRequest);
                          saveRequestsToFile();
                          console.log(`Marked cluster request ${requestId} as failed`);
                        } else {
                          console.error(`Could not find cluster request ${requestId} to mark as failed`);
                        }
                      } else if (clusterState === 'CREATING') {
                        // Still creating, update progress and ensure request stays in memory
                        const currentRequest = clusterRequests.get(requestId);
                        if (currentRequest && currentRequest.progress < 95) {
                          currentRequest.progress = Math.min(95, currentRequest.progress + 5);
                          currentRequest.statusMessage = `Cluster creation in progress in Atlas... (${Math.floor((Date.now() - currentRequest.startTime) / 1000)}s)`;
                          // Store the actual cluster ID from the status response
                          if (statusResult.id) {
                            currentRequest.clusterId = statusResult.id;
                          }
                          clusterRequests.set(requestId, currentRequest);
                          saveRequestsToFile();
                          console.log(`Updated progress for ${clusterName}: ${currentRequest.progress}%`);
                          console.log(`Request ${requestId} still in memory, total requests: ${clusterRequests.size}`);
                        }
                      } else {
                        // Handle other states (UPDATING, DELETING, etc.)
                        console.log(`Cluster "${clusterName}" is in state: ${clusterState}`);
                        const currentRequest = clusterRequests.get(requestId);
                        if (currentRequest) {
                          currentRequest.statusMessage = `Cluster is ${clusterState.toLowerCase()} in Atlas...`;
                          // Store the actual cluster ID from the status response
                          if (statusResult.id) {
                            currentRequest.clusterId = statusResult.id;
                          }
                          clusterRequests.set(requestId, currentRequest);
                          saveRequestsToFile();
                        }
                      }
                      // If still CREATING, continue with progress simulation
                    } catch (parseError) {
                      console.error('Failed to parse Atlas status response:', parseError);
                      console.error('Raw response:', statusStdout);
                      
                      // Mark cluster as failed due to parsing error
                      clearInterval(progressInterval);
                      clearInterval(statusCheckInterval);
                      
                      const failedRequest = clusterRequests.get(requestId);
                      if (failedRequest) {
                        failedRequest.state = 'FAILED';
                        failedRequest.progress = 0;
                        failedRequest.statusMessage = 'Failed to parse Atlas API response';
                        clusterRequests.set(requestId, failedRequest);
                        saveRequestsToFile();
                        console.log(`Marked cluster request ${requestId} as failed due to parsing error`);
                      }
                    }
                  } else {
                    console.error('No response from Atlas status check');
                  }
                });
              } catch (apiError) {
                console.error('Error checking Atlas status:', apiError);
              }
            }, 10000); // Check Atlas status every 10 seconds
            
            console.log(`Started monitoring Atlas status for cluster ${clusterName} every 10 seconds`);
            console.log(`Current cluster requests in memory: ${clusterRequests.size}`);
          }, 30000); // Wait 30 seconds before starting monitoring
          
        } else if (result.error || result.errorCode) {
          console.log(`Atlas API Error: ${stdout}`);
          clearInterval(progressInterval);
          const failedRequest = clusterRequests.get(requestId);
          if (failedRequest) {
            failedRequest.state = 'FAILED';
            failedRequest.progress = 0;
            failedRequest.statusMessage = `Atlas API Error: ${result.detail || result.reason || result.error || "Unknown error"}`;
            clusterRequests.set(requestId, failedRequest);
            saveRequestsToFile();
          }
        } else {
          // Unexpected response format
          console.error('Unexpected Atlas API response format:', stdout);
          clearInterval(progressInterval);
          const failedRequest = clusterRequests.get(requestId);
          if (failedRequest) {
            failedRequest.state = 'FAILED';
            failedRequest.progress = 0;
            failedRequest.statusMessage = 'Unexpected response from Atlas API';
            clusterRequests.set(requestId, failedRequest);
            saveRequestsToFile();
          }
        }
      } catch (parseError) {
        console.error('Failed to parse Atlas API response:', parseError);
        console.error('Raw response:', stdout);
        
        // Check if response is HTML (server error page)
        if (stdout && stdout.includes('<!DOCTYPE') || stdout.includes('<html')) {
          console.error('Atlas API returned HTML instead of JSON - likely server error');
          clearInterval(progressInterval);
          const failedRequest = clusterRequests.get(requestId);
          if (failedRequest) {
            failedRequest.state = 'FAILED';
            failedRequest.progress = 0;
            failedRequest.statusMessage = 'Atlas API returned HTML error page - server issue';
            clusterRequests.set(requestId, failedRequest);
            saveRequestsToFile();
          }
        } else {
          clearInterval(progressInterval);
          const failedRequest = clusterRequests.get(requestId);
          if (failedRequest) {
            failedRequest.state = 'FAILED';
            failedRequest.progress = 0;
            failedRequest.statusMessage = 'Invalid response from Atlas API';
            clusterRequests.set(requestId, failedRequest);
            saveRequestsToFile();
          }
        }
      }
    });
    
    res.json({
      success: true,
      requestId: requestId,
      message: `Cluster ${clusterName} creation initiated via MCP Server`,
      mcpFlow: true
    });
    
  } catch (error) {
    console.error('MCP Server cluster creation error:', error);
    res.status(500).json({ 
      success: false,
      error: error.message,
      message: "Failed to connect to Atlas API via MCP Server" 
    });
  }
});

// Get cluster status endpoint (alias for compatibility)
app.get('/api/status', async (req, res) => {
  try {
    const { id } = req.query;
    
    if (!id) {
      return res.status(400).json({ error: 'Request ID is required' });
    }

    const clusterRequest = clusterRequests.get(id);
    if (!clusterRequest) {
      return res.status(404).json({ error: 'Cluster request not found' });
    }

    const statusResponse = {
      id: clusterRequest.id,
      clusterName: clusterRequest.clusterName,
      tier: clusterRequest.tier,
      state: clusterRequest.state,
      progress: clusterRequest.progress,
      statusMessage: clusterRequest.statusMessage,
      clusterId: clusterRequest.clusterId,
      isDataPopulated: clusterRequest.isDataPopulated,
      dataCollections: clusterRequest.dataCollections
    };
    
    res.json(statusResponse);
    
  } catch (error) {
    console.error('Error fetching cluster status:', error);
    res.status(500).json({ error: 'Failed to fetch cluster status' });
  }
});

// Get cluster status endpoint
app.get('/api/cluster-status', async (req, res) => {
  try {
    const { id } = req.query;
    
    if (!id) {
      return res.status(400).json({ error: 'Request ID is required' });
    }

    const clusterRequest = clusterRequests.get(id);
    if (!clusterRequest) {
      return res.status(404).json({ error: 'Cluster request not found' });
    }

    const statusResponse = {
      id: clusterRequest.id,
      clusterName: clusterRequest.clusterName,
      tier: clusterRequest.tier,
      state: clusterRequest.state,
      progress: clusterRequest.progress,
      statusMessage: clusterRequest.statusMessage,
      clusterId: clusterRequest.clusterId,
      isDataPopulated: clusterRequest.isDataPopulated,
      dataCollections: clusterRequest.dataCollections
    };
    
    res.json(statusResponse);
    
  } catch (error) {
    console.error('Error fetching cluster status:', error);
    res.status(500).json({ error: 'Failed to fetch cluster status' });
  }
});

// Populate data endpoint
app.post('/api/populate-data', async (req, res) => {
  try {
    const { clusterName, requestId } = req.body;
    
    if (!clusterName || !requestId) {
      return res.status(400).json({ error: 'Cluster name and request ID are required' });
    }

    const clusterRequest = clusterRequests.get(requestId);
    if (!clusterRequest) {
      return res.status(404).json({ error: 'Cluster request not found' });
    }
    
    if (clusterRequest.isDataPopulated) {
      console.warn(`Data has already been populated for cluster ${clusterName}`);
      return res.status(400).json({ error: 'Data has already been populated' });
    }
    
    // Simulate data population through MCP server
    console.log('Starting data population for cluster:', clusterName);
    
    // Simulate the time it takes to populate data
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    console.log('Data population completed for cluster:', clusterName);
    
    // Update cluster request to mark data as populated
    clusterRequest.isDataPopulated = true;
    clusterRequest.dataCollections = ['users', 'products', 'orders', 'customers', 'transactions'];
    clusterRequests.set(requestId, clusterRequest);
    saveRequestsToFile();
    
    const responseData = {
      success: true,
      message: `Sample data populated successfully in cluster ${clusterName} via MCP Server`,
      collections: ['users', 'products', 'orders', 'customers', 'transactions'],
      mcpFlow: true
    };
    
    res.json(responseData);
    
  } catch (error) {
    console.error('Error populating data:', error);
    res.status(500).json({ error: 'Failed to populate data via MCP Server' });
  }
});

// View data endpoint
app.post('/api/view-data', async (req, res) => {
  try {
    const { clusterName, requestId } = req.body;
    
    if (!clusterName || !requestId) {
      return res.status(400).json({ error: 'Cluster name and request ID are required' });
    }

    const clusterRequest = clusterRequests.get(requestId);
    if (!clusterRequest) {
      return res.status(404).json({ error: 'Cluster request not found' });
    }
    
    if (!clusterRequest.isDataPopulated) {
      console.warn(`Data has not been populated yet for cluster ${clusterName}`);
      return res.status(400).json({ error: 'Data has not been populated yet' });
    }
    
    // Simulate data retrieval through MCP server
    console.log('Starting data retrieval for cluster:', clusterName);
    
    // Simulate the time it takes to retrieve data
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    console.log('Data retrieval completed for cluster:', clusterName);
    
    // Prepare sample data that would be retrieved from the actual cluster
    const sampleData = {
      users: [
        { _id: '1', name: 'John Doe', email: 'john@example.com', age: 30, city: 'New York', createdAt: '2024-01-15T10:30:00Z' },
        { _id: '2', name: 'Jane Smith', email: 'jane@example.com', age: 28, city: 'Los Angeles', createdAt: '2024-01-16T14:20:00Z' },
        { _id: '3', name: 'Mike Johnson', email: 'mike@example.com', age: 35, city: 'Chicago', createdAt: '2024-01-17T09:15:00Z' },
        { _id: '4', name: 'Sarah Wilson', email: 'sarah@example.com', age: 26, city: 'Miami', createdAt: '2024-01-18T16:45:00Z' },
        { _id: '5', name: 'David Brown', email: 'david@example.com', age: 32, city: 'Seattle', createdAt: '2024-01-19T11:30:00Z' }
      ],
      products: [
        { _id: '1', name: 'MacBook Pro 16"', category: 'Electronics', price: 2499.99, stock: 15, brand: 'Apple', createdAt: '2024-01-10T08:00:00Z' },
        { _id: '2', name: 'Wireless Mouse', category: 'Accessories', price: 29.99, stock: 100, brand: 'Logitech', createdAt: '2024-01-11T10:30:00Z' },
        { _id: '3', name: '4K Monitor', category: 'Electronics', price: 399.99, stock: 25, brand: 'Samsung', createdAt: '2024-01-12T14:15:00Z' },
        { _id: '4', name: 'Mechanical Keyboard', category: 'Accessories', price: 149.99, stock: 50, brand: 'Corsair', createdAt: '2024-01-13T16:20:00Z' },
        { _id: '5', name: 'USB-C Hub', category: 'Accessories', price: 79.99, stock: 75, brand: 'Anker', createdAt: '2024-01-14T12:00:00Z' }
      ],
      orders: [
        { _id: '1', userId: '1', productId: '1', quantity: 1, total: 2499.99, status: 'completed', orderDate: '2024-01-20T10:00:00Z' },
        { _id: '2', userId: '2', productId: '2', quantity: 2, total: 59.98, status: 'shipped', orderDate: '2024-01-21T14:30:00Z' },
        { _id: '3', userId: '3', productId: '3', quantity: 1, total: 399.99, status: 'processing', orderDate: '2024-01-22T09:15:00Z' },
        { _id: '4', userId: '4', productId: '4', quantity: 1, total: 149.99, status: 'completed', orderDate: '2024-01-23T16:45:00Z' },
        { _id: '5', userId: '5', productId: '5', quantity: 3, total: 239.97, status: 'shipped', orderDate: '2024-01-24T11:30:00Z' }
      ],
      customers: [
        { _id: '1', name: 'John Doe', email: 'john@example.com', phone: '+1-555-0101', address: '123 Main St, New York, NY', loyaltyPoints: 150, createdAt: '2024-01-01T00:00:00Z' },
        { _id: '2', name: 'Jane Smith', email: 'jane@example.com', phone: '+1-555-0102', address: '456 Oak Ave, Los Angeles, CA', loyaltyPoints: 75, createdAt: '2024-01-02T00:00:00Z' },
        { _id: '3', name: 'Mike Johnson', email: 'mike@exampleome.com', phone: '+1-555-0103', address: '789 Pine Rd, Chicago, IL', loyaltyPoints: 200, createdAt: '2024-01-03T00:00:00Z' }
      ],
      transactions: [
        { _id: '1', customerId: '1', amount: 2499.99, type: 'purchase', status: 'completed', timestamp: '2024-01-20T10:00:00Z' },
        { _id: '2', customerId: '2', amount: 59.98, type: 'purchase', status: 'completed', timestamp: '2024-01-21T14:30:00Z' },
        { _id: '3', customerId: '3', amount: 399.99, type: 'purchase', status: 'pending', timestamp: '2024-01-22T09:15:00Z' }
      ]
    };
    
    const responseData = {
      success: true,
      message: `Data retrieved successfully from cluster ${clusterName} via MCP Server`,
      data: sampleData,
      mcpFlow: true
    };
    
    res.json(responseData);
    
  } catch (error) {
    console.error('Error retrieving data:', error);
    res.status(500).json({ error: 'Failed to retrieve data via MCP Server' });
  }
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`MCP Server running on http://localhost:${PORT}`);
  console.log(`Persistence file: ${PERSISTENCE_FILE}`);
  console.log(`Cluster requests in memory: ${clusterRequests.size}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\nShutting down MCP Server...');
  console.log(`Saving ${clusterRequests.size} cluster requests before shutdown...`);
  
  // Save all requests before shutting down
  saveRequestsToFile();
  
  if (mcpProcess) {
    console.log('Terminating MCP process...');
    mcpProcess.kill();
  }
  
  console.log('MCP Server shutdown complete');
  process.exit(0);
});
