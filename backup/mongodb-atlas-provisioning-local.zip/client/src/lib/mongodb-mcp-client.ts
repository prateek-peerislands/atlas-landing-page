// Frontend MCP Client that communicates with local MCP server process
interface ClusterConfig {
  clusterName: string;
  cloudProvider: string;
  region: string;
  tier: string;
}

interface MCPResponse {
  success: boolean;
  message: string;
  data?: any;
  error?: string;
}

export class MongoDBMCPClient {
  public isConnected = false;
  private mcpServerPort = 3001;
  private responseHandlers: Map<string, (response: any) => void> = new Map();

  constructor() {}

  async initialize(): Promise<void> {
    console.log("Initializing Frontend → MCP Server connection...");
    
    try {
      // Test connection to local MCP server
      const response = await fetch(`http://localhost:${this.mcpServerPort}/health`);
      if (response.ok) {
        this.isConnected = true;
        console.log("Frontend → MCP Server connection established");
      } else {
        throw new Error('MCP Server not responding');
      }
    } catch (error) {
      // Start MCP server if not running
      console.log("Starting local MCP server...");
      await this.startMCPServer();
    }
  }

  private async startMCPServer(): Promise<void> {
    // Send request to start MCP server
    const response = await fetch('/api/start-mcp', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        credentials: {
          clientId: import.meta.env.VITE_MDB_MCP_API_CLIENT_ID,
          clientSecret: import.meta.env.VITE_MDB_MCP_API_CLIENT_SECRET,
          publicKey: import.meta.env.VITE_MONGODB_PUBLIC_KEY,
          privateKey: import.meta.env.VITE_MONGODB_PRIVATE_KEY
        }
      })
    });

    if (!response.ok) {
      throw new Error('Failed to start MCP server');
    }

    // Wait for server to be ready
    await new Promise(resolve => setTimeout(resolve, 3000));
    this.isConnected = true;
    console.log("MCP Server started and ready");
  }

  async createCluster(clusterName: string): Promise<MCPResponse> {
    if (!this.isConnected) {
      await this.initialize();
    }

    try {
      console.log(`Frontend → MCP Server: Creating cluster "${clusterName}"...`);
      
      // Add timeout to prevent infinite waiting
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        console.log('❌ Frontend → MCP Server timeout after 10 seconds');
        controller.abort();
      }, 10000);
      
      const response = await fetch(`http://localhost:${this.mcpServerPort}/create-cluster`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          clusterName: clusterName,
          cloudProvider: "AWS",
          region: "US_EAST_1",
          tier: "M10"
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`MCP Server error: ${response.status} ${errorText}`);
      }

      const result = await response.json();
      console.log('MCP Server → MongoDB Atlas: Cluster creation response:', result);

      // Log exact response to trace hardcoded error source
      console.log('🔍 RAW MCP Server Response:', JSON.stringify(result, null, 2));

      // Return the actual MCP server response without any transformation
      return result;

    } catch (error: any) {
      console.error('Frontend → MCP Server error:', error);
      
      // Check if this is where the IP access error is coming from
      if (error.name === 'AbortError') {
        console.log('❌ Request timed out - returning timeout error');
        return {
          success: false,
          message: 'Request timed out',
          error: 'MCP server request timed out'
        };
      }
      
      return {
        success: false,
        message: 'Failed to create cluster via MCP Server',
        error: error.message
      };
    }
  }

  // List clusters functionality removed as requested

  disconnect() {
    this.isConnected = false;
  }
}

// Create singleton instance
export const mcpClient = new MongoDBMCPClient();