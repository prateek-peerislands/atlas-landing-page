import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
interface ClusterRequest {
  clusterName: string;
  cloudProvider: string;
  region: string;
  tier: string;
}
import { mcpClient } from "@/lib/mongodb-mcp-client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Server, Info, Rocket, Loader2 } from "lucide-react";
import { FaAws } from "react-icons/fa";
import { Globe } from "lucide-react";

interface ClusterCreationCardProps {
  onProvisionStart: (requestId: string, clusterName: string) => void;
}

export default function ClusterCreationCard({ onProvisionStart }: ClusterCreationCardProps) {
  const { toast } = useToast();

  const form = useForm<ClusterRequest>({
    defaultValues: {
      clusterName: "",
      cloudProvider: "AWS", 
      region: "US_EAST_1",
      tier: "M10",
    },
  });

  const provisionMutation = useMutation({
    mutationFn: async (data: ClusterRequest) => {
      // Initialize MCP client if not already connected
      if (!mcpClient.isConnected) {
        await mcpClient.initialize();
      }
      
      // Create cluster via MCP
      console.log("🚀 Creating cluster via MCP server...");
      const response = await mcpClient.createCluster(data.clusterName);
      
      return {
        requestId: Math.random().toString(36).substring(7),
        status: "pending",
        message: "Cluster provisioning started via MCP",
        mcpResponse: response
      };
    },
    onSuccess: (data) => {
      toast({
        title: "Cluster provisioning started",
        description: "Your M10 cluster is now being provisioned directly via MCP server.",
      });
      onProvisionStart(data.requestId, form.getValues().clusterName);
    },
    onError: (error) => {
      toast({
        title: "Provisioning failed",
        description: error.message || "Failed to start cluster provisioning",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ClusterRequest) => {
    provisionMutation.mutate(data);
  };

  return (
    <Card className="bg-white shadow-lg border border-gray-200 overflow-hidden">
      <CardContent className="p-8">
        {/* Card Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-12 h-12 bg-mongodb-green bg-opacity-10 rounded-lg flex items-center justify-center">
            <Server className="text-mongodb-green text-xl" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-text-primary">Create M10 Cluster</h3>
            <p className="text-text-secondary">Deploy a production-ready MongoDB cluster</p>
          </div>
        </div>

        {/* Cluster Tier Info */}
        <div className="bg-mongodb-green bg-opacity-5 border border-mongodb-green border-opacity-20 rounded-lg p-4 mb-6">
          <div className="flex items-start space-x-3">
            <Info className="text-mongodb-green mt-1" />
            <div>
              <h4 className="font-semibold text-text-primary mb-1">M10 Cluster Specifications</h4>
              <ul className="text-sm text-text-secondary space-y-1">
                <li>• 2 vCPUs, 2GB RAM</li>
                <li>• 10GB storage (expandable)</li>
                <li>• Production-ready with replica sets</li>
                <li>• Starting at $57/month</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Cluster Creation Form */}
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Cluster Name */}
            <FormField
              control={form.control}
              name="clusterName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold text-text-primary">
                    Cluster Name <span className="text-red-500">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter cluster name (e.g., production-cluster)"
                      className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-mongodb-green focus:border-mongodb-green transition-colors"
                      {...field}
                    />
                  </FormControl>
                  <p className="text-xs text-text-secondary">Must be 1-64 characters, letters, numbers, and hyphens only</p>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid md:grid-cols-2 gap-6">
              {/* Cloud Provider */}
              <div>
                <Label className="block text-sm font-semibold text-text-primary mb-2">Cloud Provider</Label>
                <div className="relative">
                  <div className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-text-secondary cursor-not-allowed">
                    <div className="flex items-center space-x-3">
                      <FaAws className="text-orange-500" />
                      <span>Amazon Web Services (AWS)</span>
                      <span className="ml-auto text-xs bg-gray-200 px-2 py-1 rounded">Fixed</span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-text-secondary mt-1">Cloud provider is pre-configured for this deployment</p>
              </div>

              {/* Region */}
              <div>
                <Label className="block text-sm font-semibold text-text-primary mb-2">Region</Label>
                <div className="relative">
                  <div className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-text-secondary cursor-not-allowed">
                    <div className="flex items-center space-x-3">
                      <Globe className="text-blue-600" />
                      <span>US East 1 (us-east-1)</span>
                      <span className="ml-auto text-xs bg-gray-200 px-2 py-1 rounded">Fixed</span>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-text-secondary mt-1">Region optimized for performance and compliance</p>
              </div>
            </div>

            {/* Estimated Cost */}
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-text-primary">Estimated Monthly Cost</h4>
                  <p className="text-sm text-text-secondary">M10 cluster on AWS, us-east-1</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-text-primary">$57.00</div>
                  <div className="text-sm text-text-secondary">USD per month</div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-4">
              <Button
                type="submit"
                disabled={provisionMutation.isPending}
                className="w-full bg-mongodb-green hover:bg-mongodb-green hover:bg-opacity-90 text-white font-semibold py-4 px-6 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {provisionMutation.isPending ? (
                  <span className="flex items-center justify-center space-x-2">
                    <Loader2 className="animate-spin" />
                    <span>Creating...</span>
                  </span>
                ) : (
                  <span className="flex items-center justify-center space-x-2">
                    <Rocket />
                    <span>Create Cluster</span>
                  </span>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
