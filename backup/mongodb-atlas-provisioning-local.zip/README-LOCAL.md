# MongoDB Atlas Cluster Provisioning - Local Development

A React-based web application for MongoDB Atlas cluster management with MCP (Model Context Protocol) integration.

## Quick Start

1. **Run the setup script:**
   ```bash
   ./setup.sh
   ```

2. **Configure environment variables:**
   Edit `.env` file with your MongoDB Atlas credentials:
   ```env
   VITE_MONGODB_PUBLIC_KEY=your_atlas_public_key
   VITE_MONGODB_PRIVATE_KEY=your_atlas_private_key
   VITE_MDB_MCP_API_CLIENT_ID=your_service_account_client_id
   VITE_MDB_MCP_API_CLIENT_SECRET=your_service_account_client_secret
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   Navigate to `http://localhost:5000`

## Getting MongoDB Atlas Credentials

### Atlas API Keys
1. Go to [MongoDB Atlas](https://cloud.mongodb.com)
2. Navigate to Access Manager → Project API Keys
3. Create a new API key with Project Owner permissions
4. Copy the Public Key and Private Key

### Service Account Credentials
1. In Atlas, go to Access Manager → Service Accounts
2. Create a new service account
3. Assign appropriate permissions
4. Copy the Client ID and Client Secret

## Development Commands

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run check` - Run TypeScript checks
- `npm run start` - Start production server

## VSCode Integration

The setup script configures VSCode with:
- Recommended extensions for React/TypeScript development
- Tailwind CSS IntelliSense
- Debugging configuration
- Auto-formatting on save

## Architecture

- **Frontend**: React 18 + TypeScript + Vite + Tailwind CSS
- **Backend**: Express.js with TypeScript
- **MCP Integration**: Model Context Protocol for MongoDB Atlas operations
- **UI Components**: Shadcn/UI with Radix UI primitives

## Troubleshooting

### Common Issues

1. **"tsx: not found" error**
   - Run `npm install` to ensure all dependencies are installed

2. **MCP Server connection issues**
   - Verify environment variables are set correctly
   - Check that port 3001 is available

3. **Atlas API authentication errors**
   - Ensure API keys have correct permissions
   - Verify IP address is whitelisted in Atlas

### Debug Mode

To run with detailed logging:
```bash
NODE_ENV=development DEBUG=* npm run dev
```

## Project Structure

```
├── client/src/          # React frontend source
├── server/              # Express backend
├── shared/              # Shared TypeScript types
├── mcp-server.cjs       # MongoDB MCP server
├── setup.sh             # Local setup script
└── .env                 # Environment variables
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## Support

For issues and questions:
- Check the troubleshooting section above
- Review the technical documentation in `replit.md`
- Create an issue in the repository