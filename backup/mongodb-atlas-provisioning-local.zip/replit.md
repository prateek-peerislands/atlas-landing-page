# Overview

This is a minimalistic MongoDB Atlas cluster provisioning application that creates real M10 clusters via direct Frontend → MCP Server → MongoDB Atlas architecture. The application features a clean React frontend for cluster creation with real-time provisioning status, communicating directly with an MCP server for MongoDB Atlas API calls. Designed for Jefferson cluster creation in Atlas project 688ba44a7f3cd609ef39f683 with fixed M10 tier, AWS cloud provider, and US_EAST_1 region configuration. Successfully tested: Direct Atlas API cluster creation confirmed working with "lovable" cluster.

## Recent Changes (August 04, 2025)
- Fixed missing tsx dependency that was preventing application startup
- Updated TypeScript configuration with proper ES2020 target and library settings
- Resolved all 34 LSP compilation errors in mongodb-mcp-client.ts
- Created setup.sh script for local VSCode development installation
- Generated comprehensive README-LOCAL.md with setup instructions
- Packaged project as downloadable zip file (mongodb-atlas-provisioning-local.zip)

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development tooling
- **UI Library**: Shadcn/UI components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Hookform resolvers for validation
- **Design System**: Custom MongoDB Atlas-themed design with CSS variables for theming

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: TSX for TypeScript execution during development
- **Build System**: Vite for frontend bundling, esbuild for backend bundling
- **Server Setup**: Custom Vite integration for development with HMR support

## Database Integration
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: Neon Database (serverless PostgreSQL) as the primary database
- **Session Store**: PostgreSQL-based session storage using connect-pg-simple
- **Schema Management**: Drizzle Kit for database migrations and schema management

## MCP (Model Context Protocol) Integration
- **Architecture**: Frontend communicates with a local MCP server (port 3001) that handles MongoDB Atlas operations
- **Server Package**: Uses mongodb-mcp-server (user-confirmed working configuration)
- **Configuration**: Service Account credentials + Atlas API public/private keys in environment
- **Client**: Custom MongoDBMCPClient class manages communication between frontend and MCP server
- **Operations**: Cluster creation through MCP protocol with real Atlas API calls
- **Error Handling**: Comprehensive error handling and status tracking for async operations

## Authentication & Session Management
- **Session Storage**: PostgreSQL-based sessions with connect-pg-simple
- **CORS**: Configured for cross-origin requests
- **Credentials**: Cookie-based authentication with secure session handling

## Development & Deployment
- **Development**: Hot module replacement with Vite dev server integration
- **Build Process**: Separate build commands for frontend (Vite) and backend (esbuild)
- **Environment**: Environment-based configuration with dotenv
- **Logging**: Custom request logging middleware with response time tracking

# External Dependencies

## Cloud Infrastructure
- **MongoDB Atlas**: Primary database service for cluster management
- **Neon Database**: Serverless PostgreSQL for application data and session storage

## UI & Design
- **Radix UI**: Comprehensive set of low-level UI primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon sets including Microsoft Azure icons

## Development Tools
- **Vite**: Fast build tool and development server
- **TypeScript**: Type safety across the entire application
- **PostCSS**: CSS processing with Tailwind and Autoprefixer
- **ESBuild**: Fast JavaScript bundler for production builds

## Third-Party Services
- **Replit Integration**: Development environment integration with Replit-specific plugins
- **Microsoft Azure**: Cloud provider integration for MongoDB cluster deployment
- **Date-fns**: Date manipulation and formatting library

## Communication Protocols
- **MCP (Model Context Protocol)**: Communication protocol between frontend and MongoDB management services
- **REST API**: Standard HTTP API for frontend-backend communication
- **WebSocket**: Real-time communication for cluster status updates and provisioning progress

## Form & Validation
- **React Hook Form**: Performant form library with minimal re-renders
- **Class Variance Authority**: Utility for creating type-safe component variants
- **CLSX**: Conditional CSS class name utility