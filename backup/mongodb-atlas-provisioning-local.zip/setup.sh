#!/bin/bash

# MongoDB Atlas Cluster Provisioning Application - Local Setup
# This script sets up the application for local development in VSCode

echo "🚀 Setting up MongoDB Atlas Cluster Provisioning Application..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    echo "   Download from: https://nodejs.org/"
    exit 1
fi

# Check Node.js version
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version 18+ is required. Current version: $(node -v)"
    echo "   Please upgrade Node.js from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node -v) detected"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed successfully"

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating .env template..."
    cat > .env << 'EOF'
# MongoDB Atlas API Credentials
# Get these from: https://cloud.mongodb.com/v2/settings/publicApiAccess
VITE_MONGODB_PUBLIC_KEY=your_public_key_here
VITE_MONGODB_PRIVATE_KEY=your_private_key_here

# MongoDB MCP Server Credentials
# Service Account credentials for MongoDB Atlas
VITE_MDB_MCP_API_CLIENT_ID=your_client_id_here
VITE_MDB_MCP_API_CLIENT_SECRET=your_client_secret_here

# Database Configuration (if using PostgreSQL)
DATABASE_URL=your_database_url_here

# Development Settings
NODE_ENV=development
PORT=5000
EOF
    echo "✅ Created .env template file"
    echo "⚠️  Please edit .env file with your actual MongoDB Atlas credentials"
else
    echo "✅ .env file already exists"
fi

# VSCode workspace setup
echo "🔧 Setting up VSCode workspace..."

# Create .vscode directory if it doesn't exist
mkdir -p .vscode

# Create VSCode settings
cat > .vscode/settings.json << 'EOF'
{
  "typescript.preferences.importModuleSpecifier": "relative",
  "editor.formatOnSave": true,
  "editor.defaultFormatter": "esbenp.prettier-vscode",
  "editor.codeActionsOnSave": {
    "source.fixAll.eslint": "explicit"
  },
  "files.associations": {
    "*.css": "tailwindcss"
  },
  "emmet.includeLanguages": {
    "javascript": "javascriptreact",
    "typescript": "typescriptreact"
  },
  "tailwindCSS.experimental.classRegex": [
    "cva\\(([^)]*)\\)",
    "[\"'`]([^\"'`]*).*?[\"'`]"
  ]
}
EOF

# Create VSCode extensions recommendations
cat > .vscode/extensions.json << 'EOF'
{
  "recommendations": [
    "bradlc.vscode-tailwindcss",
    "esbenp.prettier-vscode",
    "ms-vscode.vscode-typescript-next",
    "ms-vscode.vscode-json",
    "formulahendry.auto-rename-tag",
    "christian-kohler.path-intellisense",
    "ms-vscode.vscode-node-azure-pack"
  ]
}
EOF

# Create launch configuration for debugging
cat > .vscode/launch.json << 'EOF'
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Launch Development Server",
      "type": "node",
      "request": "launch",
      "program": "${workspaceFolder}/node_modules/tsx/dist/cli.js",
      "args": ["server/index.ts"],
      "env": {
        "NODE_ENV": "development"
      },
      "console": "integratedTerminal",
      "internalConsoleOptions": "neverOpen",
      "skipFiles": ["<node_internals>/**"]
    }
  ]
}
EOF

echo "✅ VSCode workspace configured"

# Build check
echo "🔍 Running TypeScript check..."
npm run check

if [ $? -ne 0 ]; then
    echo "⚠️  TypeScript check found issues, but setup continues..."
else
    echo "✅ TypeScript check passed"
fi

echo ""
echo "🎉 Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your MongoDB Atlas credentials"
echo "2. Open the project in VSCode: code ."
echo "3. Install recommended extensions when prompted"
echo "4. Run the development server: npm run dev"
echo ""
echo "📚 Documentation:"
echo "   - README.md - Project overview and usage"
echo "   - replit.md - Technical architecture details"
echo ""
echo "🌐 The app will run on: http://localhost:5000"
echo ""
echo "Need help? Check the README.md file for detailed setup instructions."