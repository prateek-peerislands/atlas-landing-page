import { useState } from "react";
import ClusterCreationCard from "@/components/cluster-creation-card";
import LoadingModal from "@/components/loading-modal";
import SuccessModal from "@/components/success-modal";

export default function Home() {
  const [isProvisioning, setIsProvisioning] = useState(false);
  const [provisioningRequestId, setProvisioningRequestId] = useState<string>("");
  const [clusterName, setClusterName] = useState<string>("");
  const [showSuccess, setShowSuccess] = useState(false);

  const handleProvisionStart = (requestId: string, name: string) => {
    setProvisioningRequestId(requestId);
    setClusterName(name);
    setIsProvisioning(true);
    
    // Simulate provisioning completion after 5 seconds
    setTimeout(() => {
      setIsProvisioning(false);
      setShowSuccess(true);
    }, 5000);
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    setClusterName("");
    setProvisioningRequestId("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            MongoDB Atlas Cluster Provisioning
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Create and manage your MongoDB Atlas M10 clusters with our streamlined provisioning interface.
            Powered by direct MCP server integration for real-time cluster deployment.
          </p>
        </div>
        
        <ClusterCreationCard onProvisionStart={handleProvisionStart} />
        
{isProvisioning && (
          <LoadingModal 
            requestId={provisioningRequestId}
            onComplete={() => {
              setIsProvisioning(false);
              setShowSuccess(true);
            }}
            onError={() => {
              setIsProvisioning(false);
            }}
          />
        )}
        
        {showSuccess && (
          <SuccessModal 
            clusterName={clusterName}
            onClose={handleSuccessClose}
          />
        )}
      </div>
    </div>
  );
}