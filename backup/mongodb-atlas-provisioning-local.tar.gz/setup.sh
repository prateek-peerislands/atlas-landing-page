#!/bin/bash

# MongoDB Atlas Cluster Provisioning Application Setup
echo "🚀 Setting up MongoDB Atlas Cluster Provisioning Application..."

# Install dependencies
echo "📦 Installing Node.js dependencies..."
npm install

# Check for required environment variables
echo "🔑 Checking environment configuration..."

if [ -z "$MDB_MCP_API_CLIENT_ID" ] || [ -z "$MDB_MCP_API_CLIENT_SECRET" ]; then
    echo "⚠️  Warning: MongoDB MCP API credentials not found"
    echo "   Please set MDB_MCP_API_CLIENT_ID and MDB_MCP_API_CLIENT_SECRET"
fi

if [ -z "$MONGODB_PUBLIC_KEY" ] || [ -z "$MONGODB_PRIVATE_KEY" ]; then
    echo "⚠️  Warning: MongoDB Atlas API credentials not found"
    echo "   Please set MONGODB_PUBLIC_KEY and MONGODB_PRIVATE_KEY"
    echo "   Get these from: https://cloud.mongodb.com/v2/settings/publicApi"
fi

if [ -z "$MONGODB_PROJECT_ID" ]; then
    echo "⚠️  Warning: MongoDB Project ID not found"
    echo "   Please set MONGODB_PROJECT_ID (e.g., 688ba44a7f3cd609ef39f683)"
fi

# Create client environment file if it doesn't exist
if [ ! -f "client/.env" ]; then
    echo "📝 Creating client environment file..."
    cat > client/.env << EOF
# MongoDB Atlas Project Configuration
VITE_MONGODB_PROJECT_ID=688ba44a7f3cd609ef39f683
VITE_MCP_SERVER_URL=http://localhost:3001
EOF
    echo "✅ Created client/.env"
fi

# Check if running on local machine vs Replit
if [ -n "$REPL_ID" ]; then
    echo "🌐 Running on Replit - IP restrictions may apply"
    echo "   Atlas API calls will be blocked by organization-level IP restrictions"
    echo "   Use this for UI testing and development"
else
    echo "💻 Running on local machine"
    echo "   Add your IP to MongoDB Atlas Network Access for full functionality"
fi

echo ""
echo "🎯 Setup Complete! Next steps:"
echo "   1. Add your IP to MongoDB Atlas Network Access"
echo "   2. Run: npm run dev"
echo "   3. Open: http://localhost:5000"
echo ""
echo "📋 Architecture: Frontend → MCP Server → MongoDB Atlas"
echo "🏗️  Ready to create M10 clusters with Azure/ap-south-2 configuration"