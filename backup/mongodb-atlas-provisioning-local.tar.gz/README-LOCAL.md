# MongoDB Atlas Cluster Provisioning - Local Setup

A minimalistic React application for MongoDB Atlas M10 cluster provisioning via MCP server integration.

## System Architecture

Frontend → MCP Server → MongoDB Atlas API
- **Frontend**: React + TypeScript + Tailwind CSS
- **MCP Server**: Direct Atlas API integration with AWS/US_EAST_1 configuration
- **Authentication**: MongoDB Atlas API keys with digest authentication

## Prerequisites

- Node.js 18+ and npm
- MongoDB Atlas account with API credentials
- MongoDB Atlas project ID: `688ba44a7f3cd609ef39f683`

## Required Environment Variables

Create a `.env` file in the root directory:

```env
# MongoDB Atlas API Credentials
MONGODB_PUBLIC_KEY=your_atlas_public_key
MONGODB_PRIVATE_KEY=your_atlas_private_key

# MCP Server Credentials  
MDB_MCP_API_CLIENT_ID=your_mcp_client_id
MDB_MCP_API_CLIENT_SECRET=your_mcp_client_secret

# Project Configuration
MONGODB_PROJECT_ID=688ba44a7f3cd609ef39f683
```

## Installation & Setup

1. **Extract and navigate:**
   ```bash
   tar -xzf mongodb-atlas-provisioning-local.tar.gz
   cd mongodb-atlas-provisioning-local
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your MongoDB Atlas credentials
   ```

4. **Start the application:**
   ```bash
   npm run dev
   ```

5. **Access the application:**
   - Frontend: http://localhost:5000
   - MCP Server: http://localhost:3001

## Features

- **Direct M10 Cluster Creation**: Provisions real MongoDB Atlas M10 clusters
- **AWS US_EAST_1 Configuration**: Fixed cloud provider and region settings
- **Real-time Status Updates**: Live cluster provisioning progress
- **Authentication Error Handling**: Clear feedback for credential issues

## Cluster Configuration

All clusters are created with:
- **Tier**: M10 (2 vCPUs, 2GB RAM, 10GB storage)
- **Cloud Provider**: AWS
- **Region**: US_EAST_1
- **Replica Set**: 3-node configuration
- **Estimated Cost**: $57/month

## API Endpoints

### MCP Server (Port 3001)
- `POST /create-cluster` - Create new cluster
- `GET /health` - Health check

### Express Server (Port 5000)
- `GET /api/health` - Backend health check
- `GET /api/status` - Cluster provisioning status

## Troubleshooting

### Authentication Issues (401 Errors)
- Verify MONGODB_PUBLIC_KEY and MONGODB_PRIVATE_KEY are correct
- Check that API keys have cluster creation permissions
- Ensure IP address is whitelisted in MongoDB Atlas

### Network Issues
- Confirm ports 3001 and 5000 are available
- Check firewall settings for outbound HTTPS connections
- Verify MongoDB Atlas organization allows API access

### Common Solutions
1. **Credential Refresh**: Generate new API keys in Atlas
2. **IP Whitelisting**: Add current IP to Atlas access list
3. **Project Permissions**: Ensure API keys have project-level access

## File Structure

```
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # UI components
│   │   ├── lib/           # MCP client integration
│   │   └── pages/         # Application pages
├── server/                # Express backend
├── mcp-server.cjs         # MCP server implementation
├── package.json           # Dependencies
└── .env                   # Environment configuration
```

## Development Notes

- The MCP server automatically starts with the main application
- Environment variables are validated on startup
- All cluster creation uses direct Atlas API calls
- No persistent database required (in-memory storage)

## Support

For issues with:
- **MongoDB Atlas API**: Check Atlas documentation and API key permissions
- **MCP Server**: Verify environment variables and network connectivity
- **Frontend Issues**: Check browser console for detailed error messages